<?php
    use PHPMailer\PHPMailer\PHPMailer;
    use PHPMailer\PHPMailer\Exception;

	  require '../assets/vendor/php-email-form/PHPMailer/Exception.php';
	  require '../assets/vendor/php-email-form/PHPMailer/PHPMailer.php';
	  require '../assets/vendor/php-email-form/PHPMailer/SMTP.php';
	
    $servername='localhost';
    $username='root';
    $password='mysql';
    $dbname = "shakim";
    $conn= new mysqli ($servername,$username,$password,$dbname);

    // Check connection
    if ($conn->connect_error) {
      die("Connection failed: " . $conn->connect_error);
    }
    //echo "Connected successfully";

    $name = $email = $subject = $message = '';
if (isset($_POST['name'])) {
		$name = mysqli_real_escape_string($conn,$_POST['name']);
	  $email = mysqli_real_escape_string($conn,$_POST['email']);
    $phone = mysqli_real_escape_string($conn,$_POST['phone']);
	  $subject = mysqli_real_escape_string($conn,$_POST['subject']);
	  $message = mysqli_real_escape_string($conn,$_POST['message']);

  $sql = "INSERT INTO contact(name, email, phone, subject, message) VALUES ('$name','$email','$phone','$subject','$message')";
if ($conn->query($sql) === TRUE) {
  echo "<span class='text-success'><strong>Your message has been sent. Thank you!</strong></span>";
} else {
  echo "Error: " . $sql . "<br>" . $conn->error;
}

$html="<table><tr><td>Name</td><td>$name</td></tr><tr><td>Subject</td><td>$subject</td></tr><tr><td>Phone</td><td>$phone</td></tr><tr><td>Email</td><td>$email</td></tr><tr><td>Message</td><td>$message</td></tr></table>";
    $mail = new PHPMailer();

    //smtp setting
    $mail->isSMTP();
    $mail->Host = "smtp.gmail.com";
    $mail->SMTPAuth = true;
    $mail->Username = "shakim707@gmail.com";
    $mail->Password = "djbnqpsblcozdkiq";
    $mail->Port = 465;
    $mail->SMTPSecure = "ssl";

    //email settings
    $mail->isHTML(true);
    $mail->setFrom($email, $name);
    $mail->addAddress("shakim707@gmail.com");
    $mail->Subject = ("$email ($subject)");
    $mail->Body="$html";
    $mail->SMTPOptions=array('ssl'=>array(
      'verify_peer'=>false,
      'verify_peer_name'=>false,
      'allow_self_signed'=>false
    ));
if ($mail->send()) {
      //echo "Mail Send";
}else{
      echo "Error occur";
}

}
  $conn->close();
?>