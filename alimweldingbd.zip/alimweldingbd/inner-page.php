<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="utf-8">
  <meta content="width=device-width, initial-scale=1.0" name="viewport">

  <title>Alim | Welding | Workshop | Naogaon</title>
  <!-- <base href="https://www.alimweldingbd.com/" /> -->
  <meta name="language" content="bn" /> 
  <meta http-equiv="Content-Language" content="bn" /> 
  <meta name="robots" content="alim welding naogaon">
  <meta name="googlebot" content="alim welding naogaon" />
  <meta name="googlebot-news" content="alim welding naogaon" />
  <meta name="Developer" content="Md. Shakim Hossain" />
  <meta name="Developed By" content="Md. Shakim Hossain" />
  <meta name="propeller" content="cf3d93daee2cc94d6c89200a87935b1b" />
  <meta name="google-site-verification" content="_JcfyGLu-M-P88rgYIRlvsdFYZRPGeng4Ri5JuxvSY8" />
  <meta name="msvalidate.01" content="8DB9F4C3D539E57F5EC78BAE1D489691" />
  <meta name="alexaVerifyID" content="Alim Welding Naogaon" />
  <meta name="keywords" content="a, aa, ai, ail, al, ali, alim, alm, alim w, alim wel, alim weld, alim welding, alim store, alim welding store, alim wellding, alim well, alim welding work, alim welding shop, alim welding workshop, alim welding workshop nao, alim welding workshop naogaon, na, nao, naogaon, naogaon welding, naogaon workshop, naougan, gas, naogaon engineer, gas engineer, alim sardar, alim mondal, welding sardarpara, sardar para weding, sordarpara welding ar dokan, alim sardar para, alim sordar para, jalai, jhalai ar dokan, shit ar dokan, angel, flotbar, dril, dril machine, w, we, wel, wild, well, wld, work, shop, workshop, wellding, wolling, wolling dokan, welding work, welding workshop and more, অ, আ, আলিম, আলি, আলিম ওয়েলডিং, আলিম ওয়েলডিং ওয়ার্কসপ, আলিম ওয়েলডিং দোকান, আলিম ওয়েলডিং নওগাঁ, আলিম দোকান, আলিম স্টোর, আলিম মন্ডল, আলিম সরদারপাড়া, আলিম ইন্জিনিয়ারিং ওয়ার্কসপ, আলিম ওয়ার্কসপ, আলিম ইন্জিনিয়ার, আলিম সিটের দোকান, আলিম এঙ্গেলের দোকান, আলিম ঝালাইয়ের দোকান, আলিম ঝালাই, আলিম ড্রিল মেশিন, আলিম স্টিল আলমারি" />
  <meta name="description" content="Alim Welding Naogaon. Most Largest And Popular In Naogaon Bangladesh" />
  <meta name="author" content="Alim Welding Naogaon" />
  <meta name="url" content="https://www.alimweldingbd.com" />

  <!-- Favicons -->
  <link rel="apple-touch-icon" sizes="180x180" href="assets/img/apple-touch-icon.png">
  <link rel="icon" type="image/png" sizes="32x32" href="assets/img/favicon-32x32.png">
  <link rel="icon" type="image/png" sizes="16x16" href="assets/img/favicon-16x16.png">
  <link rel="manifest" href="/site.webmanifest">

  <!-- Google Fonts -->
  <link href="https://fonts.googleapis.com/css?family=Open+Sans:300,300i,400,400i,600,600i,700,700i|Raleway:300,300i,400,400i,600,600i,700,700i,900" rel="stylesheet">

  <!-- Vendor CSS Files -->
  <link href="assets/vendor/animate.css/animate.min.css" rel="stylesheet">
  <link href="assets/vendor/aos/aos.css" rel="stylesheet">
  <link href="assets/vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">
  <link href="assets/vendor/bootstrap-icons/bootstrap-icons.css" rel="stylesheet">
  <link href="assets/vendor/boxicons/css/boxicons.min.css" rel="stylesheet">
  <link href="assets/vendor/glightbox/css/glightbox.min.css" rel="stylesheet">
  <link href="assets/vendor/swiper/swiper-bundle.min.css" rel="stylesheet">

  <!-- Template Main CSS File -->
  <script type="text/javascript" src="assets/js/jquery.js"></script>
  <script type="text/javascript" src="assets/js/acmeticker.js"></script>
  <link rel="stylesheet" href="assets/css/style1.css">
  <link href="assets/css/style.css" rel="stylesheet">

  <!-- =======================================================
  * Template Name: Mamba - v4.6.0
  * Template URL: https://bootstrapmade.com/mamba-one-page-bootstrap-template-free/
  * Author: BootstrapMade.com
  * License: https://bootstrapmade.com/license/
  ======================================================== -->
</head>

<body>

  <!-- ======= Top Bar ======= -->
  <section id="topbar" class="d-flex align-items-center">
    <div class="container d-flex justify-content-center justify-content-md-between">
      <div class="contact-info d-flex align-items-center">
        <i class="bi bi-envelope-fill"></i><a href="mailto:contact@example.com">alimweldingn707@gmail.com</a>
        <i class="bi bi-phone-fill phone-icon"></i> +880 1731 002 089
      </div>
      <div class="social-links d-none d-md-block">
        <a href="#" class="twitter"><i class="bi bi-twitter"></i></a>
        <a href="#" class="facebook"><i class="bi bi-facebook"></i></a>
        <a href="#" class="instagram"><i class="bi bi-instagram"></i></a>
        <a href="#" class="linkedin"><i class="bi bi-linkedin"></i></i></a>
      </div>
    </div>
  </section>

  <!-- ======= Header ======= -->
  <header id="header" class="d-flex align-items-center">
    <div class="container d-flex align-items-center">

      <div class="logo me-auto">
        <!-- <h1><a href="index.php">AWWN</a></h1> -->
        <!-- Uncomment below if you prefer to use an image logo -->
        <a href="index.php"><img src="assets/img/alim-welding-logo.png" alt="" class="img-fluid"></a>
      </div>

      <nav id="navbar" class="navbar">
        <ul>
          <li><a class="nav-link scrollto " href="#hero">Home</a></li>
          <li><a class="nav-link scrollto" href="#about">About</a></li>
          <li><a class="nav-link scrollto" href="#services">Services</a></li>
          <li><a class="nav-link scrollto" href="#portfolio">Portfolio</a></li>
          <li><a class="nav-link scrollto" href="#team">Team</a></li>
          <li class="dropdown"><a href="#"><span>Drop Down</span> <i class="bi bi-chevron-down"></i></a>
            <ul>
              <li><a href="#">Drop Down 1</a></li>
              <li class="dropdown"><a href="#"><span>Deep Drop Down</span> <i class="bi bi-chevron-right"></i></a>
                <ul>
                  <li><a href="#">Deep Drop Down 1</a></li>
                  <li><a href="#">Deep Drop Down 2</a></li>
                  <li><a href="#">Deep Drop Down 3</a></li>
                  <li><a href="#">Deep Drop Down 4</a></li>
                  <li><a href="#">Deep Drop Down 5</a></li>
                </ul>
              </li>
              <li><a href="#">Drop Down 2</a></li>
              <li><a href="#">Drop Down 3</a></li>
              <li><a href="#">Drop Down 4</a></li>
            </ul>
          </li>
          <li><a class="nav-link scrollto" href="#contact">Contact</a></li>
        </ul>
        <i class="bi bi-list mobile-nav-toggle"></i>
      </nav><!-- .navbar -->

    </div>
  </header><!-- End Header -->

  <!-- ======= News Ticker Section ======= -->
  <div class="acme-news-ticker">
    <div class="acme-news-ticker-label">Alim Welding Naogaon</div>
    <div class="acme-news-ticker-box">
        <ul class="my-news-ticker">
            <li><a href="#">ALIM WELDING WORKSHOP Here we welding and steel work including doors, windows, grills, boundary gates, collapsible gates, shuttering gates, SS pipe stair railings, grills, doors, steel cupboards, sockets, subboxers, design tables, office tables, file cabinets. Carefully crafted by skilled artisans. Address: Par-Naogaon, Sardar Para, Jiban-Sandhi Road, Ward No. 07, Naogaon Sadar, Naogaon. Contact: 01731002089, 01310611346, 01571336695</a></li>
            <li><a href="#">&#10021</a></li>
            <li><a href="#">&#10021</a></li>
            <li><a href="#">আলিম ওয়েল্ডিং ওয়ার্কশপ, এখানে আমরা দরজা, জানালা, গ্রিল, বাউন্ডারি গেট, কলাপসিবল গেট, শাটারিং গেট, এসএস পাইপের সিঁড়ি রেলিং, গ্রিল, দরজা, স্টিলের আলমারি, সোকেচ, সাববাক্সর, ডেসিন টেবিল, অফিস টেবিল, ফাইল কেবিনেট সহ ওয়েল্ডিং এবং স্টিলের কাজ সুদক্ষ কারিগর দ্বারা যত্নসহকারে করা হয়। ঠিকানা: পার-নওগাঁ, সরদার পাড়া, জীবন-সন্ধি রোড, ওয়ার্ড নং ০৭, নওগাঁ সদর, নওগাঁ। যোগাযোগ: ০১৭৩১০০২০৮৯, ০১৩১০৬১১৩৪৬, ০১৫৭১৩৩৬৬৯৫</a></li>
            <li><a href="#">&#10020</a></li>
            <li><a href="#">&#10031</a></li>
            <li><a href="#">&#10045</a></li>
            <li><a href="#">&#10057</a></li>
        </ul>
    </div>
    <div class="acme-news-ticker-controls acme-news-ticker-horizontal-controls">
        <button class="acme-news-ticker-pause"></button>
    </div>
  </div>
  <script type="text/javascript">
    jQuery(document).ready(function ($) {
        $('.my-news-ticker').AcmeTicker({
            type:'marquee',/*horizontal/horizontal/Marquee/type*/
            direction: 'left',/*up/down/left/right*/
            speed: 0.05,/*true/false/number*/ /*For vertical/horizontal 600*//*For marquee 0.05*//*For typewriter 50*/
            controls: {
                toggle: $('.acme-news-ticker-pause'),/*Can be used for horizontal/horizontal/typewriter*//*not work for marquee*/
            }
        });
    })
  </script><!-- ======= End News Ticker Section ======= -->



  <main id="main">

    <!-- ======= Breadcrumbs Section ======= -->
    <section class="breadcrumbs">
      <div class="container">

        <div class="d-flex justify-content-between align-items-center">
          <h2>Inner Page</h2>
          <ol>
            <li><a href="index.php">Home</a></li>
            <li>Inner Page</li>
          </ol>
        </div>

      </div>
    </section><!-- End Breadcrumbs Section -->

    <section class="inner-page">
      <div class="container">
        <p>
          Example inner page template
        </p>
      </div>
    </section>

  </main><!-- End #main -->

  <!-- ======= Footer ======= -->
  <footer id="footer">
    <div class="footer-top">
      <div class="container">
        <div class="row">

          <div class="col-lg-3 col-md-6 footer-info">
            <h3>Alim Welding Naogaon</h3>
            <p>
              Par-Naogaon, Sardar Para, <br>
              Jibon Shondhi Road, <br>
              Ward No: 07, <br>
              Naogaon Sadar, Naogaon. <br>
              Dhaka, Bangladesh. <br><br>
              <strong>Phone:</strong> +880 1731 002 089<br>
              <strong>Email:</strong> alimweldingn707@gmail.com<br>
            </p>
            <div class="social-links mt-3">
              <a href="#" class="twitter"><i class="bx bxl-twitter"></i></a>
              <a href="#" class="facebook"><i class="bx bxl-facebook"></i></a>
              <a href="#" class="instagram"><i class="bx bxl-instagram"></i></a>
              <a href="#" class="google-plus"><i class="bx bxl-skype"></i></a>
              <a href="#" class="linkedin"><i class="bx bxl-linkedin"></i></a>
            </div>
          </div>

          <div class="col-lg-2 col-md-6 footer-links">
            <h4>Useful Links</h4>
            <ul>
              <li><i class="bx bx-chevron-right"></i> <a href="#">Home</a></li>
              <li><i class="bx bx-chevron-right"></i> <a href="#">About us</a></li>
              <li><i class="bx bx-chevron-right"></i> <a href="#">Services</a></li>
              <li><i class="bx bx-chevron-right"></i> <a href="#">Terms of service</a></li>
              <li><i class="bx bx-chevron-right"></i> <a href="#">Privacy policy</a></li>
            </ul>
          </div>

          <div class="col-lg-3 col-md-6 footer-links">
            <h4>Our Services</h4>
            <ul>
              <li><i class="bx bx-chevron-right"></i> <a href="#">Web Design</a></li>
              <li><i class="bx bx-chevron-right"></i> <a href="#">Web Development</a></li>
              <li><i class="bx bx-chevron-right"></i> <a href="#">Product Management</a></li>
              <li><i class="bx bx-chevron-right"></i> <a href="#">Marketing</a></li>
              <li><i class="bx bx-chevron-right"></i> <a href="#">Graphic Design</a></li>
            </ul>
          </div>

          <div class="col-lg-4 col-md-6 footer-newsletter">
            <h4>Our Newsletter</h4>
            <p>Tamen quem nulla quae legam multos aute sint culpa legam noster magna</p>
            <form action="" method="post">
              <input type="email" name="email"><input type="submit" value="Subscribe">
            </form>

          </div>

        </div>
      </div>
    </div>

    <div class="container">
      <div class="copyright">
        &copy; Copyright <strong><span>Alim Welding Naogaon</span></strong>. All Rights Reserved
      </div>
      <div class="credits">
        Designed by <a href="https://www.w3schools.com/bootstrap5/index.php">Md. Shakim Hossain</a>
      </div>
    </div>
  </footer><!-- End Footer -->

  <a href="#" class="back-to-top d-flex align-items-center justify-content-center"><i class="bi bi-arrow-up-short"></i></a>

  <!-- Vendor JS Files -->
  <script src="assets/vendor/aos/aos.js"></script>
  <script src="assets/vendor/bootstrap/js/bootstrap.bundle.min.js"></script>
  <script src="assets/vendor/glightbox/js/glightbox.min.js"></script>
  <script src="assets/vendor/isotope-layout/isotope.pkgd.min.js"></script>
  <script src="assets/vendor/php-email-form/validate.js"></script>
  <script src="assets/vendor/purecounter/purecounter.js"></script>
  <script src="assets/vendor/swiper/swiper-bundle.min.js"></script>

  <!-- Template Main JS File -->
  <script src="assets/js/main.js"></script>

</body>

</html>